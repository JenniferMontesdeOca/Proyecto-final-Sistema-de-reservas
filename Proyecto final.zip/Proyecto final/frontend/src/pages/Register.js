import React, { useState, useEffect } from 'react';
import '../styles.css';
import { useNavigate } from 'react-router-dom';

const Register = () => {
  const [fullname, setFullname] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [formVisible, setFormVisible] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    setTimeout(() => setFormVisible(true), 100);
  }, []);

  const handleRegister = async (e) => {
    e.preventDefault();

    try {
      const res = await fetch('http://localhost:3001/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fullname, email, password }),
      });

      if (!res.ok) throw new Error('Error al registrar usuario');

      alert('Registro exitoso');
      setFullname('');
      setEmail('');
      setPassword('');
      navigate('/login');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="container">
      <div className="frame frame-long">
        <div className="nav">
          <ul className="links">
            <li className="signup-active"><a className="btn">Registro</a></li>
            <li className="signin-inactive">
              <a className="btn" onClick={() => navigate('/login')}>Sign in</a>
            </li>
          </ul>
        </div>

        <form
          onSubmit={handleRegister}
          className={`form-signup ${formVisible ? 'form-signup-left' : ''}`}
        >
          <label htmlFor="fullname">Nombre completo</label>
          <input
            id="fullname"
            className="form-styling"
            type="text"
            placeholder="Nombre completo"
            value={fullname}
            onChange={(e) => setFullname(e.target.value)}
            required
          />

          <label htmlFor="email">Correo electrónico</label>
          <input
            id="email"
            className="form-styling"
            type="email"
            placeholder="Correo electrónico"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <label htmlFor="password">Contraseña</label>
          <input
            id="password"
            className="form-styling"
            type="password"
            placeholder="Contraseña"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <button type="submit" className="btn-signup">Registrarse</button>
        </form>

        {error && <p style={{ color: 'red', textAlign: 'center' }}>{error}</p>}
      </div>
    </div>
  );
};

export default Register;
