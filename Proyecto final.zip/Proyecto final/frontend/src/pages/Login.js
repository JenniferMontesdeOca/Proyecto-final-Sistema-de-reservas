import React, { useState, useEffect } from 'react';
import '../styles.css';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [formVisible, setFormVisible] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    setTimeout(() => setFormVisible(true), 100);
  }, []);

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const res = await fetch('http://localhost:3001/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      if (!res.ok) throw new Error('Credenciales incorrectas');

      const data = await res.json();
      localStorage.setItem('token', data.token);
      navigate('/home');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="container">
      <div className="frame">
        <div className="nav">
          <ul className="links">
            <li className="signin-active"><a className="btn">Login</a></li>
            <li className="signup-inactive">
              <a className="btn" onClick={() => navigate('/register')}>Sign up</a>
            </li>
          </ul>
        </div>

        <form onSubmit={handleLogin} className={`form-signin ${formVisible ? '' : 'form-signin-left'}`}>
          <label htmlFor="email">Correo electrónico</label>
          <input
            className="form-styling"
            type="email"
            id="email"
            value={email}
            placeholder="Correo electrónico"
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <label htmlFor="password">Contraseña</label>
          <input
            className="form-styling"
            type="password"
            id="password"
            value={password}
            placeholder="Contraseña"
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <button className="btn-signin" type="submit">Iniciar sesión</button>
        </form>

        {error && <p style={{ color: 'red', textAlign: 'center' }}>{error}</p>}
      </div>
    </div>
  );
};

export default Login;
