import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../styles.css";

function Reserve() {
  const [form, setForm] = useState({
    space_id: "",
    fecha: "",
    hora_inicio: "",
    hora_fin: "",
  });

  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("token");
      const res = await fetch("http://localhost:3001/api/reservations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(form),
      });

      if (!res.ok) throw new Error("Error al hacer la reserva");

      alert("Reserva exitosa");
      setForm({ space_id: "", fecha: "", hora_inicio: "", hora_fin: "" });
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <>
      {/* NAVBAR */}
      <div className="container-fluid position-relative nav-bar p-0">
        <div className="container-lg position-relative p-0 px-lg-3" style={{ zIndex: 9 }}>
          <nav className="navbar navbar-expand-lg bg-light navbar-light shadow-lg py-3 py-lg-0 pl-3 pl-lg-5">
            <Link to="/" className="navbar-brand">
              <h1 className="m-0 text-primary"><span className="text-dark">SALÓN</span> EVENTS</h1>
            </Link>
            <button type="button" className="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse justify-content-between px-3" id="navbarCollapse">
              <div className="navbar-nav ml-auto py-0">
                <Link to="/home" className="nav-item nav-link">Inicio</Link>
                <Link to="/reserve" className="nav-item nav-link active">Reservar</Link>
                <Link to="/my-reservations" className="nav-item nav-link">Mis Reservas</Link>
                <button
                  onClick={handleLogout}
                  className="nav-item nav-link btn btn-link"
                  style={{ padding: 0, marginLeft: "15px" }}
                >
                  Cerrar Sesión
                </button>
              </div>
            </div>
          </nav>
        </div>
      </div>

      {/* FORMULARIO DE RESERVA */}
      <div className="container-fluid booking mt-5 pb-5">
        <div className="container pb-5">
          <div className="bg-light shadow" style={{ padding: 30 }}>
            <form onSubmit={handleSubmit}>
              <div className="row align-items-center" style={{ minHeight: "60px" }}>
                <div className="col-md-3">
                  <input
                    name="space_id"
                    type="number"
                    className="form-control p-4"
                    placeholder="ID del Espacio"
                    value={form.space_id}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="col-md-3">
                  <input
                    name="fecha"
                    type="date"
                    className="form-control p-4"
                    placeholder="Fecha"
                    value={form.fecha}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="col-md-2">
                  <input
                    name="hora_inicio"
                    type="time"
                    className="form-control p-4"
                    placeholder="Hora inicio"
                    value={form.hora_inicio}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="col-md-2">
                  <input
                    name="hora_fin"
                    type="time"
                    className="form-control p-4"
                    placeholder="Hora fin"
                    value={form.hora_fin}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="col-md-2">
                  <button type="submit" className="btn btn-primary btn-block" style={{ height: 47, marginTop: "-2px" }}>
                    Reservar
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}

export default Reserve;
