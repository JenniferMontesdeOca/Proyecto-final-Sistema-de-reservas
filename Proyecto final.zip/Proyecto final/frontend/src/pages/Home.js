import React from "react";
import { Link, useNavigate } from "react-router-dom";
import "../styles.css";

function Home() {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  return (
    <>
      {/* NAVBAR */}
      <div className="container-fluid position-relative nav-bar p-0">
        <div className="container-lg position-relative p-0 px-lg-3" style={{ zIndex: 9 }}>
          <nav className="navbar navbar-expand-lg bg-light navbar-light shadow-lg py-3 py-lg-0 pl-3 pl-lg-5">
            <Link to="/" className="navbar-brand">
              <h1 className="m-0 text-primary"><span className="text-dark">SALÓN</span> EVENTS</h1>
            </Link>
            <button type="button" className="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse justify-content-between px-3" id="navbarCollapse">
              <div className="navbar-nav ml-auto py-0">
                <Link to="/home" className="nav-item nav-link active">Inicio</Link>
                <Link to="/reserve" className="nav-item nav-link">Reservar</Link>
                <Link to="/my-reservations" className="nav-item nav-link">Mis Reservas</Link>
                <button
                  onClick={handleLogout}
                  className="nav-item nav-link btn btn-link"
                  style={{ padding: 0, marginLeft: "15px" }}
                >
                  Cerrar Sesión
                </button>
              </div>
            </div>
          </nav>
        </div>
      </div>

      {/* CARRUSEL */}
      <div className="container-fluid p-0">
        <div id="header-carousel" className="carousel slide" data-ride="carousel">
          <div className="carousel-inner">
            <div className="carousel-item active">
              <img className="w-100" src="/img/bodanoche.jpg" alt="Salón 1" />
              <div className="carousel-caption d-flex flex-column align-items-center justify-content-center">
                <div className="p-3" style={{ maxWidth: 900 }}>
                  <h4 className="text-white text-uppercase mb-md-3">Reservas Online</h4>
                  <h1 className="display-3 text-white mb-md-4">Tu evento comienza aquí</h1>
                  <Link to="/reserve" className="btn btn-primary py-md-3 px-md-5 mt-2">Reservar</Link>
                </div>
              </div>
            </div>
            <div className="carousel-item">
              <img className="w-100" src="/img/capuchinas.jpg" alt="Salón 2" />
              <div className="carousel-caption d-flex flex-column align-items-center justify-content-center">
                <div className="p-3" style={{ maxWidth: 900 }}>
                  <h4 className="text-white text-uppercase mb-md-3">Espacios exclusivos</h4>
                  <h1 className="display-3 text-white mb-md-4">Ideal para bodas y eventos</h1>
                  <Link to="/reserve" className="btn btn-primary py-md-3 px-md-5 mt-2">Reservar</Link>
                </div>
              </div>
            </div>
          </div>
          <a className="carousel-control-prev" href="#header-carousel" data-slide="prev">
            <div className="btn btn-dark" style={{ width: 45, height: 45 }}>
              <span className="carousel-control-prev-icon mb-n2"></span>
            </div>
          </a>
          <a className="carousel-control-next" href="#header-carousel" data-slide="next">
            <div className="btn btn-dark" style={{ width: 45, height: 45 }}>
              <span className="carousel-control-next-icon mb-n2"></span>
            </div>
          </a>
        </div>
      </div>
    </>
  );
}

export default Home;
