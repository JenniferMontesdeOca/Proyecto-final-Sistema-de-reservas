import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../styles.css";

function MyReservations() {
  const [reservations, setReservations] = useState([]);
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  const fetchReservations = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await fetch("http://localhost:3001/api/reservations", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!res.ok) throw new Error("Error al obtener reservas");

      const data = await res.json();
      setReservations(data);
    } catch (err) {
      alert(err.message);
    }
  };

  const handleCancel = async (id) => {
    try {
      const token = localStorage.getItem("token");
      const res = await fetch(`http://localhost:3001/api/reservations/${id}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!res.ok) throw new Error("Error al cancelar reserva");

      alert("Reserva cancelada");
      fetchReservations(); // Recargar lista
    } catch (err) {
      alert(err.message);
    }
  };

  useEffect(() => {
    fetchReservations();
  }, []);

  return (
    <>
      {/* NAVBAR */}
      <div className="container-fluid position-relative nav-bar p-0">
        <div className="container-lg position-relative p-0 px-lg-3" style={{ zIndex: 9 }}>
          <nav className="navbar navbar-expand-lg bg-light navbar-light shadow-lg py-3 py-lg-0 pl-3 pl-lg-5">
            <Link to="/" className="navbar-brand">
              <h1 className="m-0 text-primary"><span className="text-dark">SALÓN</span> EVENTS</h1>
            </Link>
            <button type="button" className="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse justify-content-between px-3" id="navbarCollapse">
              <div className="navbar-nav ml-auto py-0">
                <Link to="/home" className="nav-item nav-link">Inicio</Link>
                <Link to="/reserve" className="nav-item nav-link">Reservar</Link>
                <Link to="/my-reservations" className="nav-item nav-link active">Mis Reservas</Link>
                <button
                  onClick={handleLogout}
                  className="nav-item nav-link btn btn-link"
                  style={{ padding: 0, marginLeft: "15px" }}
                >
                  Cerrar Sesión
                </button>
              </div>
            </div>
          </nav>
        </div>
      </div>

      {/* TABLA DE RESERVAS */}
      <div className="container mt-5">
        <h2 className="text-center mb-4">Mis Reservas</h2>
        {reservations.length === 0 ? (
          <p className="text-center">No tienes reservas.</p>
        ) : (
          <div className="table-responsive">
            <table className="table table-bordered table-hover shadow">
              <thead className="thead-dark">
                <tr>
                  <th>ID</th>
                  <th>Espacio</th>
                  <th>Fecha</th>
                  <th>Hora Inicio</th>
                  <th>Hora Fin</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {reservations.map((r) => (
                  <tr key={r.id}>
                    <td>{r.id}</td>
                    <td>{r.space_id}</td>
                    <td>{r.fecha}</td>
                    <td>{r.hora_inicio}</td>
                    <td>{r.hora_fin}</td>
                    <td>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => handleCancel(r.id)}
                      >
                        Cancelar
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}

export default MyReservations;
