import React from 'react';
export default function Espacios(){
  return <div className="container"><h2>Espacios Page</h2></div>;
}