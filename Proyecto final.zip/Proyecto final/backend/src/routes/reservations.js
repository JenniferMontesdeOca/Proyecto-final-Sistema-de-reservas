const express = require('express');
const router = express.Router();
const {
  getUserReservations,
  cancelReservation,
} = require('../controllers/reservationsController');
const verifyToken = require('../middleware/authMiddleware');

// Obtener reservas del usuario autenticado
router.get('/my-reservations', verifyToken, getUserReservations);

// Cancelar una reserva por ID
router.delete('/reservations/:id', verifyToken, cancelReservation);

module.exports = router;
