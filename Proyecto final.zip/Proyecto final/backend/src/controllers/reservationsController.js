const db = require('../db');

// Obtener reservas del usuario loggeado
const getUserReservations = async (req, res) => {
  try {
    const userId = req.user.id;

    const result = await db.query(
      'SELECT * FROM reservations WHERE user_id = $1 ORDER BY fecha, hora_inicio',
      [userId]
    );

    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener reservas' });
  }
};

// Cancelar una reserva
const cancelReservation = async (req, res) => {
  try {
    const userId = req.user.id;
    const reservationId = req.params.id;

    // Validar que la reserva sea del usuario
    const result = await db.query(
      'DELETE FROM reservations WHERE id = $1 AND user_id = $2 RETURNING *',
      [reservationId, userId]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Reserva no encontrada o no autorizada' });
    }

    res.json({ message: 'Reserva cancelada' });
  } catch (err) {
    res.status(500).json({ error: 'Error al cancelar reserva' });
  }
};

module.exports = {
  getUserReservations,
  cancelReservation,
};
