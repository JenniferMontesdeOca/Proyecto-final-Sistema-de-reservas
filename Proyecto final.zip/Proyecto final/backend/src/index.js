require('dotenv').config();
const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { Pool } = require('pg');

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
});

const app = express();
app.use(cors());
app.use(express.json());

// Auth routes
app.post('/api/auth/register', async (req, res) => {
  const { fullname, email, password } = req.body;
  const hash = await bcrypt.hash(password, 10);
  await pool.query(
    'INSERT INTO users(fullname,email,password) VALUES($1,$2,$3)',
    [fullname, email, hash]
  );
  res.sendStatus(201);
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const result = await pool.query('SELECT * FROM users WHERE email=$1', [email]);
  const user = result.rows[0];
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ id: user.id, fullname: user.fullname }, process.env.JWT_SECRET);
  res.json({ token });
});

// Spaces
app.get('/api/spaces', async (req, res) => {
  const result = await pool.query('SELECT * FROM spaces');
  res.json(result.rows);
});

// Middleware para rutas protegidas
const auth = (req, res, next) => {
  const header = req.headers.authorization;
  if (!header) return res.status(401).send('No token');
  const token = header.split(' ')[1];
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    res.status(403).send('Invalid token');
  }
};

// Reservations
app.get('/api/reservations', auth, async (req, res) => {
  const result = await pool.query('SELECT * FROM reservations WHERE user_id=$1', [req.user.id]);
  res.json(result.rows);
});

app.post('/api/reservations', auth, async (req, res) => {
  const { space_id, fecha, hora_inicio, hora_fin } = req.body;
  const result = await pool.query(
    'INSERT INTO reservations(user_id,space_id,fecha,hora_inicio,hora_fin) VALUES($1,$2,$3,$4,$5) RETURNING *',
    [req.user.id, space_id, fecha, hora_inicio, hora_fin]
  );
  res.status(201).json(result.rows[0]);
});

app.delete('/api/reservations/:id', auth, async (req, res) => {
  await pool.query('DELETE FROM reservations WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id]);
  res.sendStatus(204);
});

app.listen(3001, () => console.log('Backend listening on port 3001'));
